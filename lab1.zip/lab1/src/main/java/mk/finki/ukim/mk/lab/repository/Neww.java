//package mk.finki.ukim.mk.lab.repository;
//
//import mk.finki.ukim.mk.lab.bootstrap.DataHolder;
//import mk.finki.ukim.mk.lab.model.Event;
//import mk.finki.ukim.mk.lab.model.EventBooking;
//import mk.finki.ukim.mk.lab.model.Location;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//public class Neww {
//    public class EventRepository {
//
//
//        public List<Event> findAll() {
//            return DataHolder.events;
//        }
//
//        public List<Event> searchEventsByText(String text) {
//            return DataHolder.events.stream()
//                    .filter(e -> e.getName().contains(text) ||
//                            e.getDescription().contains(text))
//                    .toList();
//        }
//
//        public List<Event> searchEventsByRating(Double rating) {
//            return DataHolder.events.stream()
//                    .filter(e -> e.getPopularityScore() >= rating)
//                    .toList();
//        }
//
//        public List<Event> searchEventsByTextAndRating(String text, Double rating) {
//            return DataHolder.events.stream()
//                    .filter(e -> (e.getName().contains(text) || e.getDescription().contains(text)) &&
//                            (e.getPopularityScore() >= rating))
//                    .toList();
//        }
//
//        public void saveEventBooking(EventBooking eventBooking) {
//            DataHolder.eventBookingList.add(eventBooking);
//        }
//
//        public void addEvent(Event event) {
//            DataHolder.events.add(event);
//        }
//
//        public Event findbyId(Long eventId) {
//            return DataHolder.events.stream()
//                    .filter(e -> e.getId().equals(eventId))
//                    .findFirst()
//                    .orElse(null);
//
//        }
//
//        public void deleteEvent(Long eventId) {
//            List<Event> events = DataHolder.events;
//            events.removeIf(e -> e.getId().equals(eventId));
//        }
//
//        @Repository
//        public class LocationRepository {
//            public List<Location> findAll() {
//                return DataHolder.locations;
//            }
//
//            public Location findLocation(Long id) {
//                return DataHolder.locations.stream()
//                        .filter(l -> l.getId().equals(id))
//                        .findFirst()
//                        .orElse(null);
//            }
//        }
//    }
//}
