package mk.finki.ukim.mk.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.EventBooking;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.EventRepository;
import mk.finki.ukim.mk.lab.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events;
    public static List<EventBooking> eventBookingList;
    public static List<Location> locations;
    private final LocationRepository locationRepository;
    private final EventRepository eventRepository;

    @Autowired
    public DataHolder(LocationRepository locationRepository, EventRepository eventRepository) {
        this.locationRepository = locationRepository;
        this.eventRepository = eventRepository;
    }

    @PostConstruct
    public void init() {
        locations = new ArrayList<>();
        if(locationRepository.count()==0) {
            for (int i = 0; i < 5; i++) {
                Location location = new Location("LocName" + i, "Address" + i, "Capacity" + i, "Desc" + i);
                locations.add(location);
            }
            this.locationRepository.saveAll(locations);
        }
        events = new ArrayList<>();
        if(eventRepository.count()==0) {
            for (int i = 0; i < 10; i++) {
                Event event = new Event("Name" + i, "Description" + i, i, locationRepository.findAll().get(0));
                events.add(event);
            }
            this.eventRepository.saveAll(events);
        }

        eventBookingList = new ArrayList<>();
    }
}
