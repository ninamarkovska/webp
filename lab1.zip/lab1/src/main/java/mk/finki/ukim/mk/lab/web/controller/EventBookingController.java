package mk.finki.ukim.mk.lab.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.EventBooking;
import mk.finki.ukim.mk.lab.service.EventBookingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@AllArgsConstructor
public class EventBookingController {

    private final EventBookingService eventBookingService;

    @PostMapping("/eventBooking")
    public String createBooking(@RequestParam("numTickets") int numTickets,
                                @RequestParam("event") String event,
                                @RequestHeader(value = "User-Agent", required = false) String userAgent,
                                HttpServletRequest request,
                                Model model) {
        String remoteAddr = request.getRemoteAddr();
        EventBooking eventBooking = eventBookingService.placeBooking(event, userAgent, remoteAddr, numTickets);

        model.addAttribute("eventBooking", eventBooking);

        return "bookingConfirmation";
    }
}